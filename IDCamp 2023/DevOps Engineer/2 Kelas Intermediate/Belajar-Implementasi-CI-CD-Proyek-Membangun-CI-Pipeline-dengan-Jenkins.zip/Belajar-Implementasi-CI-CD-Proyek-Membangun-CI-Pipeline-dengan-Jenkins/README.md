https://github.com/bancarafarros/a428-cicd-labs

https://github.com/bancarafarros/simple-python-pyinstaller-app
